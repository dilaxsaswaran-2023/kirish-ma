import React from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import './styles.css';
import './workspace.css';
import './platform.css';
import './flow-manager.css';
import './operations-hierarchy.css';

createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
